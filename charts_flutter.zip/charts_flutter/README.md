# Flutter Charting library

[![pub package](https://img.shields.io/pub/v/charts_flutter.svg)](https://pub.dartlang.org/packages/charts_flutter)

Material Design data visualization library written natively in Dart.

## Supported charts

See the [online gallery](https://google.github.io/charts/flutter/gallery.html).

## Using the library

The `/example/` folder inside `charts_flutter` in the [GitHub repo](https://github.com/google/charts)
contains a full Flutter app with many demo examples.

## Development
This project is developed internally at Google and published for external
consumption, external contributions unfortunately cannot be taken at this time.
